# Breezze — frontend visual reference pack

Created from the supplied `breezze_flutter(1).zip` as a **visual-only UI reference**, merged with the current Breezze four-tab, global-player architecture and monochrome brand.

Includes 16 phone-size (390 × 844) SVG concepts: Home, Browse, Library, Search, Now Playing, Lyrics, Artist, Album, Playlist, Sign In, Settings, Downloads, Queue, Onboarding, Replay, and Account; plus a combined SVG design board and PNG overview.

This is **not** a completed editable Figma component library. The Figma connector returned a Starter-plan tool-call limit. You can import each SVG into the existing Breezze Figma file at https://www.figma.com/design/ekwtakfmPO7IPjMAbu1iZC and use them as composition references while building native editable components.

No third-party album art was supplied by the ZIP, so all concept artwork is generated from gradient shapes. Names/tracks are layout placeholders, not real catalog or streaming claims. Real Breezze Flutter functionality continues to use the authorized resolver, existing API, and Riverpod player. Do not ship these placeholders as live content.
