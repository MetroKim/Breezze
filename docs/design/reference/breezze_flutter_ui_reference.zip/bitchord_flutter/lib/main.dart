import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'state/player_state.dart';
import 'theme/app_theme.dart';
import 'screens/now_playing_screen.dart';

void main() {
  runApp(const BitChordApp());
}

class BitChordApp extends StatelessWidget {
  const BitChordApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => PlayerState(),
      child: MaterialApp(
        title: 'BitChord',
        debugShowCheckedModeBanner: false,
        theme: appTheme,
        home: const NowPlayingScreen(),
      ),
    );
  }
}
