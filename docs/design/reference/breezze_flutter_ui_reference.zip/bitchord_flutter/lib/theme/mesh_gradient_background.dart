import 'dart:ui';
import 'package:flutter/material.dart';
import '../models/track.dart';

/// Flutter has no built-in "mesh gradient" widget, so this approximates the
/// look from the banner (soft overlapping color blobs derived from the
/// artwork) with a few blurred, positioned circles instead of a literal port
/// of `MeshGradientBackground` / `rememberArtworkColors`, which aren't in the
/// uploaded files.
class MeshGradientBackground extends StatelessWidget {
  final ArtworkPalette palette;
  final Widget child;

  const MeshGradientBackground({
    super.key,
    required this.palette,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: Colors.black),
        Positioned(
          top: -80,
          left: -60,
          child: _blob(palette.primary, 320),
        ),
        Positioned(
          bottom: -100,
          right: -80,
          child: _blob(palette.secondary, 360),
        ),
        Positioned(
          top: 200,
          right: -40,
          child: _blob(palette.tertiary, 240),
        ),
        BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 80, sigmaY: 80),
          child: Container(color: Colors.transparent),
        ),
        Container(color: Colors.black.withOpacity(0.25)),
        child,
      ],
    );
  }

  Widget _blob(Color color, double size) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color.withOpacity(0.9),
      ),
    );
  }
}
