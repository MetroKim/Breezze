import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state/player_state.dart';
import '../theme/mesh_gradient_background.dart';
import '../widgets/seek_bar.dart';
import '../widgets/transport_controls.dart';
import 'lyrics_screen.dart';

class NowPlayingScreen extends StatelessWidget {
  const NowPlayingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<PlayerState>(
      builder: (context, player, _) {
        final track = player.current;
        final currentLine = track.lineAt(player.position);

        return MeshGradientBackground(
          palette: track.palette,
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                children: [
                  const SizedBox(height: 8),
                  const Text('Playing from Search',
                      style: TextStyle(color: Colors.white70, fontSize: 13)),
                  const Spacer(),
                  AspectRatio(
                    aspectRatio: 1,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.asset(
                        track.albumArtAsset,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          color: Colors.white10,
                          child: const Icon(Icons.music_note, size: 64, color: Colors.white54),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(track.title,
                                style: const TextStyle(
                                    fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white)),
                            Text(track.artist,
                                style: const TextStyle(fontSize: 16, color: Colors.white70)),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: Icon(
                          player.isFavorite ? Icons.star : Icons.star_border,
                          color: Colors.white,
                        ),
                        onPressed: player.toggleFavorite,
                      ),
                      IconButton(
                        icon: const Icon(Icons.more_horiz, color: Colors.white),
                        onPressed: () {},
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  if (currentLine != null)
                    InkWell(
                      onTap: () => Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => const LyricsScreen()),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              currentLine.text,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(color: Colors.white, fontSize: 15),
                            ),
                          ),
                          const Icon(Icons.chevron_right, color: Colors.white70),
                        ],
                      ),
                    ),
                  const SizedBox(height: 16),
                  SeekBar(
                    position: player.position,
                    duration: track.duration,
                    onSeek: player.seekTo,
                  ),
                  const SizedBox(height: 8),
                  TransportControls(
                    isPlaying: player.isPlaying,
                    onPrevious: player.previous,
                    onPlayPause: player.togglePlayPause,
                    onNext: player.next,
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
