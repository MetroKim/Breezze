import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state/player_state.dart';
import '../theme/mesh_gradient_background.dart';

class LyricsScreen extends StatelessWidget {
  const LyricsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<PlayerState>(
      builder: (context, player, _) {
        final track = player.current;
        final currentLine = track.lineAt(player.position);

        return MeshGradientBackground(
          palette: track.palette,
          child: SafeArea(
            child: Column(
              children: [
                Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.keyboard_arrow_down, color: Colors.white),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                    Expanded(
                      child: Column(
                        children: [
                          Text(track.title,
                              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                          Text(track.artist,
                              style: const TextStyle(color: Colors.white70, fontSize: 12)),
                        ],
                      ),
                    ),
                    const SizedBox(width: 48),
                  ],
                ),
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 32),
                    children: track.lyrics.map((line) {
                      final isCurrent = line == currentLine;
                      final widget = Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        child: Text(
                          line.text,
                          style: TextStyle(
                            color: isCurrent ? Colors.white : Colors.white38,
                            fontSize: isCurrent ? 26 : 20,
                            fontWeight: isCurrent ? FontWeight.bold : FontWeight.normal,
                          ),
                        ),
                      );
                      // Approximates the blurred, dimmed non-active lines seen
                      // in the banner's lyrics screen.
                      return isCurrent
                          ? widget
                          : ImageFiltered(
                              imageFilter: ImageFilter.blur(sigmaX: 1.2, sigmaY: 1.2),
                              child: widget,
                            );
                    }).toList(),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
