import 'package:flutter/material.dart';

class TransportControls extends StatelessWidget {
  final bool isPlaying;
  final VoidCallback onPrevious;
  final VoidCallback onPlayPause;
  final VoidCallback onNext;

  const TransportControls({
    super.key,
    required this.isPlaying,
    required this.onPrevious,
    required this.onPlayPause,
    required this.onNext,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        IconButton(
          iconSize: 32,
          icon: const Icon(Icons.fast_rewind_rounded),
          onPressed: onPrevious,
        ),
        IconButton(
          iconSize: 48,
          icon: Icon(isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded),
          onPressed: onPlayPause,
        ),
        IconButton(
          iconSize: 32,
          icon: const Icon(Icons.fast_forward_rounded),
          onPressed: onNext,
        ),
      ],
    );
  }
}
