import 'package:flutter/material.dart';

/// A single timed lyric line. [start] is when this line becomes active.
class LyricLine {
  final Duration start;
  final String text;

  const LyricLine(this.start, this.text);
}

/// Stands in for what `rememberArtworkColors` produced in the original app:
/// a couple of dominant colors pulled from the album art, fed into the
/// mesh-style background. Here it's just hardcoded per mock track instead of
/// computed from a real image, since no real artwork/analysis pipeline is
/// available to port.
class ArtworkPalette {
  final Color primary;
  final Color secondary;
  final Color tertiary;

  const ArtworkPalette({
    required this.primary,
    required this.secondary,
    required this.tertiary,
  });
}

class Track {
  final String id;
  final String title;
  final String artist;
  final String albumArtAsset;
  final Duration duration;
  final ArtworkPalette palette;
  final List<LyricLine> lyrics;
  final bool explicit;

  const Track({
    required this.id,
    required this.title,
    required this.artist,
    required this.albumArtAsset,
    required this.duration,
    required this.palette,
    this.lyrics = const [],
    this.explicit = false,
  });

  /// The lyric line active at [position], or null if none has started yet.
  LyricLine? lineAt(Duration position) {
    LyricLine? current;
    for (final line in lyrics) {
      if (line.start <= position) {
        current = line;
      } else {
        break;
      }
    }
    return current;
  }
}

class Release {
  final String title;
  final String type; // e.g. "Single", "Album"
  final int year;
  final String artAsset;

  const Release({
    required this.title,
    required this.type,
    required this.year,
    required this.artAsset,
  });
}

class Artist {
  final String name;
  final String heroImageAsset;
  final Release latestRelease;
  final List<Track> topTracks;

  const Artist({
    required this.name,
    required this.heroImageAsset,
    required this.latestRelease,
    required this.topTracks,
  });
}
