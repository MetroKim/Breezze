import 'package:flutter/material.dart';
import '../models/track.dart';

/// Placeholder catalog. The real app's search/streaming source isn't visible
/// in the uploaded files, so this exists only to drive the UI.
class MockCatalog {
  static final blindingLights = Track(
    id: 'blinding_lights',
    title: 'Blinding Lights',
    artist: 'The Weeknd',
    albumArtAsset: 'assets/images/blinding_lights.jpg',
    duration: const Duration(minutes: 3, seconds: 19),
    palette: const ArtworkPalette(
      primary: Color(0xFFB3401F),
      secondary: Color(0xFFE8A33D),
      tertiary: Color(0xFF7A1F12),
    ),
    lyrics: const [
      LyricLine(Duration(seconds: 28), "I've been on my own for long enough"),
      LyricLine(Duration(seconds: 32), "Maybe you can show me how to love, maybe"),
      LyricLine(Duration(seconds: 36), "I'm going through withdrawals"),
      LyricLine(Duration(seconds: 40), "You don't even have to do too much"),
    ],
  );

  static final swim = Track(
    id: 'swim',
    title: 'Swim',
    artist: 'Chase Atlantic',
    albumArtAsset: 'assets/images/swim.jpg',
    duration: const Duration(minutes: 3, seconds: 2),
    explicit: true,
    palette: const ArtworkPalette(
      primary: Color(0xFF1A1A1A),
      secondary: Color(0xFF3A1416),
      tertiary: Color(0xFF0D0D0D),
    ),
    lyrics: const [
      LyricLine(Duration(seconds: 10), "Yeah, I bet you feel it now, baby"),
      LyricLine(Duration(seconds: 14), "Especially since we've only known"),
      LyricLine(Duration(seconds: 17), "Each other one summer"),
      LyricLine(Duration(seconds: 21), "But I've gotta work this shit out, baby"),
      LyricLine(Duration(seconds: 25), "I'm exorcising demons, got 'em running 'round the house"),
    ],
  );

  static final sza = Artist(
    name: 'SZA',
    heroImageAsset: 'assets/images/sza_hero.jpg',
    latestRelease: const Release(
      title: 'BOY IN RED',
      type: 'Single',
      year: 2026,
      artAsset: 'assets/images/boy_in_red.jpg',
    ),
    topTracks: [blindingLights, swim],
  );

  static List<Track> get queue => [blindingLights, swim];
}
