import 'dart:async';
import 'package:flutter/foundation.dart';
import '../models/track.dart';
import '../data/mock_catalog.dart';

/// Mimics the now-playing/transport logic. There's no real audio engine wired
/// up here — just a timer ticking a fake position — since no streaming or
/// local-playback source was present in the uploaded project files.
class PlayerState extends ChangeNotifier {
  List<Track> _queue = MockCatalog.queue;
  int _index = 0;
  Duration _position = Duration.zero;
  bool _isPlaying = false;
  bool _shuffle = false;
  final Set<String> _favorites = {};
  Timer? _ticker;

  Track get current => _queue[_index];
  Duration get position => _position;
  bool get isPlaying => _isPlaying;
  bool get shuffle => _shuffle;
  bool get isFavorite => _favorites.contains(current.id);

  void play() {
    _isPlaying = true;
    _ticker?.cancel();
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_position >= current.duration) {
        next();
        return;
      }
      _position += const Duration(seconds: 1);
      notifyListeners();
    });
    notifyListeners();
  }

  void pause() {
    _isPlaying = false;
    _ticker?.cancel();
    notifyListeners();
  }

  void togglePlayPause() => _isPlaying ? pause() : play();

  void seekTo(Duration newPosition) {
    _position = newPosition;
    notifyListeners();
  }

  void next() {
    _index = (_index + 1) % _queue.length;
    _position = Duration.zero;
    notifyListeners();
  }

  void previous() {
    // Restart current track if more than 3s in, mirroring common player UX.
    if (_position > const Duration(seconds: 3)) {
      _position = Duration.zero;
    } else {
      _index = (_index - 1 + _queue.length) % _queue.length;
      _position = Duration.zero;
    }
    notifyListeners();
  }

  void toggleShuffle() {
    _shuffle = !_shuffle;
    if (_shuffle) {
      _queue = List.of(_queue)..shuffle();
    } else {
      _queue = MockCatalog.queue;
    }
    notifyListeners();
  }

  void toggleFavorite() {
    if (isFavorite) {
      _favorites.remove(current.id);
    } else {
      _favorites.add(current.id);
    }
    notifyListeners();
  }

  void playTrack(Track track) {
    final idx = _queue.indexWhere((t) => t.id == track.id);
    _index = idx == -1 ? 0 : idx;
    _position = Duration.zero;
    play();
  }

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }
}
