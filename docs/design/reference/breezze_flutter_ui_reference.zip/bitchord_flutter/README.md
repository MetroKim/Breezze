# BitChord (Flutter scaffold)

This is **not** a line-for-line port — the uploaded project only contained
`build.gradle.kts`, `ADDITIONAL.md`, `CODE_OF_CONDUCT.md`, a `.git` metadata
folder (no tracked source), and the banner image. There was no actual
Kotlin/Compose source (`app/` module, `backend/`, lyrics pipeline) to
translate line-by-line.

## What this scaffold reproduces
Built directly from the banner screenshot and the versioning/build comments
in `build.gradle.kts`:
- **Now Playing screen** — album art, title/artist, favorite + overflow
  buttons, current lyric line with a chevron into full lyrics, seek bar,
  transport controls.
- **Lyrics screen** — full lyric list, current line bold and bright, others
  dimmed and blurred.
- **Artist screen** — hero image, share/profile icons, shuffle, big play
  button, favorite, latest-release card.
- **Per-track background color** — approximates `rememberArtworkColors` /
  `MeshGradientBackground` with blurred colored blobs in
  `lib/theme/mesh_gradient_background.dart`, since Flutter has no built-in
  mesh-gradient primitive and the real algorithm wasn't in the uploaded files.
- **Version scheme** — `pubspec.yaml`'s `1.10.0+42` mirrors the
  `bitchordVersionName` / `bitchordVersionCode` pairing from the Gradle file.

## What's mocked, not ported
No real source existed for any of this, so it's stubbed:
- **Audio playback** — `PlayerState` fakes position with a `Timer`, no actual
  decoder/streaming.
- **Catalog/search** — `lib/data/mock_catalog.dart` hardcodes two tracks and
  one artist.
- **Listen Together (party server) sync** — not implemented; `backend/README.md`
  was referenced in `ADDITIONAL.md` but never uploaded.
- **Lyrics translation pipeline** — not implemented; same situation,
  referenced in `docs/LYRICS_TRANSLATION.md`, not uploaded.
- **Watch app / in-app updater** — Wear OS has no Flutter equivalent handled
  here; update-check logic isn't implemented.

## Running it
```
flutter pub get
flutter run
```
Add real album art to `assets/images/` (referenced paths: `blinding_lights.jpg`,
`swim.jpg`, `sza_hero.jpg`, `boy_in_red.jpg`) or the screens fall back to
placeholder icons/colors.

## To actually finish this
Share `app/src/main/.../NowPlayingScreen.kt` (and friends) and the two
referenced docs, and I can replace the mocked logic here with a real port
instead of a UI approximation.
